jdbc:postgresql://google/<your-database-name>?cloudSqlInstance=<your-instance-name>&socketFactory=com.google.cloud.sql.postgres.SocketFactory&user=<username>&password=<password>


# posgresql
jdbc:postgresql://google/datafolks?cloudSqlInstance=datahubpsql&socketFactory=com.google.cloud.sql.postgres.SocketFactory&user=posgres&password=berkah325